System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, _dec, _class, _temp, _crd, ccclass, property, EmisssionCalculator;

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "e5236eQUIdAErLRBWprzVX2", "EmissionCalculator", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * Predefined variables
       * Name = EmisssionCalculator
       * DateTime = Sun Nov 20 2022 13:13:55 GMT+1300 (New Zealand Daylight Time)
       * Author = jackhasaboat
       * FileBasename = EmisssionCalculator.ts
       * FileBasenameNoExtension = EmisssionCalculator
       * URL = db://assets/scripts/EmisssionCalculator.ts
       * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
       *
       */

      _export("EmisssionCalculator", EmisssionCalculator = (_dec = ccclass('EmisssionCalculator'), _dec(_class = (_temp = class EmisssionCalculator extends Component {
        constructor() {
          super(...arguments);

          _defineProperty(this, "emission_factor", 0.207);

          _defineProperty(this, "rugby_factor", 124);
        }

        //1kgCO2e = 124 rugby balls
        start() {// [3]
        }

        calculateEmissionkgCo2(weightInGram) {
          // return (weightInGram/1000 * this.emission_factor).toFixed(3)
          return Math.round(weightInGram * this.emission_factor) / 1000;
        }

        calculateEmissionInRugbySize(weightInGram) {
          return Math.round(this.calculateEmissionkgCo2(weightInGram) * this.rugby_factor * 1000) / 1000;
        } // update (deltaTime: number) {
        //     // [4]
        // }


      }, _temp)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=EmissionCalculator.js.map