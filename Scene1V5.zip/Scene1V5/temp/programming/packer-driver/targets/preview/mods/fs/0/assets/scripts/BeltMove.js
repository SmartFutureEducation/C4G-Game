System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, beltMoveSpeedGlobal, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, BeltMove;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfbeltMoveSpeedGlobal(extras) {
    _reporterNs.report("beltMoveSpeedGlobal", "./GameManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
    }, function (_unresolved_2) {
      beltMoveSpeedGlobal = _unresolved_2.beltMoveSpeedGlobal;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a682fx4VpdB4YnEUfmLvHv0", "BeltMove", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BeltMove", BeltMove = (_dec = ccclass('BeltMove'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class BeltMove extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "belt_1", _descriptor, this);

          _initializerDefineProperty(this, "belt_2", _descriptor2, this);

          _defineProperty(this, "_beltMoveSpeed", 10);

          _defineProperty(this, "_beltY", 0);

          _defineProperty(this, "_beltMovingRange", 960);
        }

        start() {
          console.log('_beltMoveSpeed: ' + this._beltMoveSpeed);
          console.log('beltMoveSpeedGlobal: ' + (_crd && beltMoveSpeedGlobal === void 0 ? (_reportPossibleCrUseOfbeltMoveSpeedGlobal({
            error: Error()
          }), beltMoveSpeedGlobal) : beltMoveSpeedGlobal));
          this._beltMoveSpeed = _crd && beltMoveSpeedGlobal === void 0 ? (_reportPossibleCrUseOfbeltMoveSpeedGlobal({
            error: Error()
          }), beltMoveSpeedGlobal) : beltMoveSpeedGlobal;

          this._init();
        }

        _init() {
          console.log('Conveyor Belt Initing..');
          console.log(this);
          console.log('Belt_1...');
          console.log(this.belt_1);
          this.belt_1.setPosition(0, this._beltY, 0);
          console.log('Belt_2...');
          console.log(this.belt_2);
          this.belt_2.setPosition(960, this._beltY, 0);
        }

        update(deltaTime) {
          this._beltMove(deltaTime);
        }

        _beltMove(deltaTime) {
          this.belt_1.setPosition(this.belt_1.position.x - this._beltMoveSpeed * deltaTime, this._beltY, 0);

          if (this.belt_1.position.x < -this._beltMovingRange) {
            this.belt_1.setPosition(this._beltMovingRange, this._beltY, 0);
          }

          this.belt_2.setPosition(this.belt_2.position.x - this._beltMoveSpeed * deltaTime, this._beltY, 0);

          if (this.belt_2.position.x < -this._beltMovingRange) {
            this.belt_2.setPosition(this._beltMovingRange, this._beltY, 0);
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "belt_1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "belt_2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=BeltMove.js.map