import { _decorator, Component, Button, sys } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = DonateLink
 * DateTime = Mon Dec 05 2022 22:43:05 GMT+1300 (New Zealand Daylight Time)
 * Author = jackhasaboat
 * FileBasename = DonateLink.ts
 * FileBasenameNoExtension = DonateLink
 * URL = db://assets/scripts/DonateLink.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */

 @ccclass('DonateLink')
 export class DonateLink extends Component {
    //  @property(Button)
    //  button: Button | null = null;
    //  onLoad () {
    //      this.button.node.on(Button.EventType.CLICK, this.callback, this);
    //  }
 
    @property(String)
    link: String = null;

    onLoad () {
        this.node.on(Button.EventType.CLICK, this.callback, this);
    }

    callback (button: Button) {
        if (this.link == 'donate'){
            sys.openURL('https://docs.google.com/forms/d/e/1FAIpQLSdT7ENkoyiY2K_MZoFxUvTy5FtNp_Awjuw9Rb7PxerNm3hjsw/viewform?usp=sharing')
        }else if (this.link == 'feedback'){
            sys.openURL('https://docs.google.com/forms/d/e/1FAIpQLScodpSGp2TuQl0mMCRmoT3jIIqy8VA9-Ppox8WZyEvfni4mwA/viewform?usp=sharing')
        }
     }
 }