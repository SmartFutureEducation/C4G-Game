System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, Collider2D, Contact2DType, Sprite, Color, Label, find, AudioSource, wasteItemsMap, Waste_Type_Enum, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, WasteCollect;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfwasteItemsMap(extras) {
    _reporterNs.report("wasteItemsMap", "./WasteList", _context.meta, extras);
  }

  function _reportPossibleCrUseOfWaste_Type_Enum(extras) {
    _reporterNs.report("Waste_Type_Enum", "./WasteList", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Collider2D = _cc.Collider2D;
      Contact2DType = _cc.Contact2DType;
      Sprite = _cc.Sprite;
      Color = _cc.Color;
      Label = _cc.Label;
      find = _cc.find;
      AudioSource = _cc.AudioSource;
    }, function (_unresolved_2) {
      wasteItemsMap = _unresolved_2.default;
    }, function (_unresolved_3) {
      Waste_Type_Enum = _unresolved_3.Waste_Type_Enum;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "906fdghJe5KfYXtzaaDo4U3", "WasteCollect", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("WasteCollect", WasteCollect = (_dec = ccclass('WasteCollect'), _dec2 = property(Node), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class WasteCollect extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "scoreBoard", _descriptor, this);

          _initializerDefineProperty(this, "tips", _descriptor2, this);

          _defineProperty(this, "isWasteCollected", false);
        }

        // reference full scripts from help doc https://docs.cocos.com/creator/manual/en/physics-2d/physics-2d-contact-callback.html
        start() {
          // Registering callback functions for a single collider
          let collider = this.getComponent(Collider2D);

          if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            collider.on(Contact2DType.END_CONTACT, this.onEndContact, this);
            collider.on(Contact2DType.PRE_SOLVE, this.onPreSolve, this);
            collider.on(Contact2DType.POST_SOLVE, this.onPostSolve, this);
          } // find score lable: https://docs.cocos.com/creator/manual/en/scripting/access-node-component.html


          this.scoreBoard = find("Canvas/scoreLabel");
          this.tips = find("Canvas/tipsLabel");
        }

        onBeginContact(selfCollider, otherCollider, contact) {
          // will be called once when two colliders begin to contact
          // console.log('onBeginContact');
          let wastCollectionCorect = false; // record whether the waste collection is correct

          let scoreChange = 0; // count scores when moving the waste to the correct bin

          this.isWasteCollected = true; // check the waste type

          let wasteName = this.node.getComponent(Sprite).spriteFrame.name;
          let wasteType = (_crd && wasteItemsMap === void 0 ? (_reportPossibleCrUseOfwasteItemsMap({
            error: Error()
          }), wasteItemsMap) : wasteItemsMap).get(wasteName); // effects while move the waste item to a waste bin

          if (otherCollider.tag == 11) {
            // recycling
            this.node.getComponent(Sprite).color = new Color(255, 255, 0);

            if (wasteType == (_crd && Waste_Type_Enum === void 0 ? (_reportPossibleCrUseOfWaste_Type_Enum({
              error: Error()
            }), Waste_Type_Enum) : Waste_Type_Enum).Recycling) {
              // verify whether moved to the correct bin
              wastCollectionCorect = true;
              this.tips.getComponent(Label).string = "correct!";
            } else if (wasteType == (_crd && Waste_Type_Enum === void 0 ? (_reportPossibleCrUseOfWaste_Type_Enum({
              error: Error()
            }), Waste_Type_Enum) : Waste_Type_Enum).General_Waste) {
              wastCollectionCorect = false;
              this.tips.getComponent(Label).string = wasteName + " is not recyclable";
            }
          } else if (otherCollider.tag == 12) {
            // general waste
            this.node.getComponent(Sprite).color = new Color(255, 0, 0);

            if (wasteType == (_crd && Waste_Type_Enum === void 0 ? (_reportPossibleCrUseOfWaste_Type_Enum({
              error: Error()
            }), Waste_Type_Enum) : Waste_Type_Enum).General_Waste) {
              // verify whether moved to the correct bin
              wastCollectionCorect = true;
              this.tips.getComponent(Label).string = "correct!";
            } else if (wasteType == (_crd && Waste_Type_Enum === void 0 ? (_reportPossibleCrUseOfWaste_Type_Enum({
              error: Error()
            }), Waste_Type_Enum) : Waste_Type_Enum).Recycling) {
              wastCollectionCorect = false;
              this.tips.getComponent(Label).string = wasteName + " is recyclable";
            }
          }

          this.node.setScale(0.75, 0.75, 0.75);

          if (wastCollectionCorect == true) {
            scoreChange = 50; // easy way to play a sound effect; more complex code & example pls reference https://docs.cocos.com/creator/3.4/manual/en/audio-system/audiosource.html

            find("Canvas/Audio/AudioYes").getComponent(AudioSource).play();
          } else if (wastCollectionCorect == false) {
            scoreChange = -50;
            find("Canvas/Audio/AudioWrong").getComponent(AudioSource).play();
          } // const animationComponent = this.node.getComponent(Animation);
          // animationComponent.play()
          // add score
          // practice string handling
          // another option but requires es2017: this.scoreBoard.getComponent(Label).string = "Score: " + (Number(this.scoreBoard.getComponent(Label).string.split("Score: ")[1]) + 50).toString().padStart(5, '0')
          // this.scoreBoard.getComponent(Label).string = "Score: " + ("00000" + (Number(this.scoreBoard.getComponent(Label).string.split("Score: ")[1]) + scoreChange)).slice(-5)      


          let score = Number(this.scoreBoard.getComponent(Label).string.split("Score: ")[1]) + scoreChange;

          if (score < 0) {
            // if the score becomes negative number, just keep the score as zero
            score = 0;
          }

          this.scoreBoard.getComponent(Label).string = ("00000" + score).slice(-5);
          setTimeout(() => {
            this.node.destroy();
          }, 500); // seems the timeout is required, else errors will be reported while running
        }

        onEndContact(selfCollider, otherCollider, contact) {
          // will be called once when the contact between two colliders just about to end.
          console.log('onEndContact');
        }

        onPreSolve(selfCollider, otherCollider, contact) {
          // will be called every time collider contact should be resolved
          console.log('onPreSolve');
        }

        onPostSolve(selfCollider, otherCollider, contact) {
          // will be called every time collider contact should be resolved
          console.log('onPostSolve');
        }

        update(deltaTime) {// if (this.isWasteCollected == false){
          //     this.node.setPosition(this.node.position.x, this.node.position.y - 50 * deltaTime)
          // }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "scoreBoard", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "tips", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=WasteCollect.js.map