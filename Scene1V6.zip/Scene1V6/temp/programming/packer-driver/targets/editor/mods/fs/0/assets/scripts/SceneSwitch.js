System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, director, _dec, _dec2, _class, _class2, _descriptor, _temp, _crd, ccclass, property, SceneSwitch;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      director = _cc.director;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "fb202wZ4mhNp7ShSsh3cGaG", "SceneSwitch", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * Predefined variables
       * Name = SceneSwitch
       * DateTime = Tue Jul 26 2022 18:18:33 GMT+1200 (New Zealand Standard Time)
       * Author = jackhasaboat
       * FileBasename = SceneSwitch.ts
       * FileBasenameNoExtension = SceneSwitch
       * URL = db://assets/scripts/SceneSwitch.ts
       * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
       *
       */

      _export("SceneSwitch", SceneSwitch = (_dec = ccclass('SceneSwitch'), _dec2 = property(String), _dec(_class = (_class2 = (_temp = class SceneSwitch extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "nextScene", _descriptor, this);
        }

        start() {// director.loadScene("scene")
        }

        onLoad() {
          this.node.on('click', this.callback, this);
        }

        callback(event) {
          // var button = event.detail;
          if (this.nextScene == "MainScene") {
            director.loadScene("scene");
          } else if (this.nextScene == "GameOver") {
            director.loadScene("scene-end");
          } else if (this.nextScene == "Start") {
            director.loadScene("scene-start");
          }
        } // update (deltaTime: number) {
        //     // [4]
        // }


      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "nextScene", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=SceneSwitch.js.map