
import { _decorator, Component, Node, __private } from 'cc';
const { ccclass, property } = _decorator;

export let beltMoveSpeedGlobal = 1

@ccclass('GameManager')
export class GameManager extends Component {
 
    @property(Number)
    beltSpeed: number=20

    private static _instance: GameManager

    public emissionTotal = 0
    public rugbyTotal = 0

    onLoad(){
        if (this.beltSpeed > 0 ){
            beltMoveSpeedGlobal = this.beltSpeed
        }
    }

    private constructor(){
        super();
    }

    public static get Instance(){
        return this._instance || (this._instance = new this());
    }


    start () {
    }

    // update (deltaTime: number) {
    //     // [4]
    // }

    // Notice the Cocos Creator "Life Cycle Callbacks" sequence
    // Check the difference when calling "beltMoveSpeedGlobal = this.beltSpeed" in onLoad() or Start() functions
    // Cocos doc:  
    // https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
    // 
}

