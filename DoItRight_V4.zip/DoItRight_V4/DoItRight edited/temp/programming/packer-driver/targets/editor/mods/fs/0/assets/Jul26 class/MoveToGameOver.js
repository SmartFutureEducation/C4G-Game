System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, director, _dec, _class, _crd, ccclass, property, MoveToGameOver;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      director = _cc.director;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "eb53f4NbrtFi6BI/1lFmXBD", "MoveToGameOver", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * Predefined variables
       * Name = MoveToGameOver
       * DateTime = Tue Jul 26 2022 19:41:15 GMT+1200 (New Zealand Standard Time)
       * Author = jackhasaboat
       * FileBasename = MoveToGameOver.ts
       * FileBasenameNoExtension = MoveToGameOver
       * URL = db://assets/MoveToGameOver.ts
       * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
       *
       */

      _export("MoveToGameOver", MoveToGameOver = (_dec = ccclass('MoveToGameOver'), _dec(_class = class MoveToGameOver extends Component {
        start() {// [3]
        }

        onLoad() {
          this.node.on('click', this.callback, this);
        }

        callback() {
          director.loadScene("scene-game-over");
        } // update (deltaTime: number) {
        //     // [4]
        // }


      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=MoveToGameOver.js.map