/// <reference path="C:\CocosDashboard_1.2.2\resources\.editors\Creator\3.4.2\resources\resources\3d\engine\@types\jsb.d.ts"/>
