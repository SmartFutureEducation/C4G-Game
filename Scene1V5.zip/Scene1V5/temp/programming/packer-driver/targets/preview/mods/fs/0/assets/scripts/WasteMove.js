System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, Prefab, instantiate, Sprite, resources, SpriteFrame, beltMoveSpeedGlobal, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, WasteMove;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfbeltMoveSpeedGlobal(extras) {
    _reporterNs.report("beltMoveSpeedGlobal", "./GameManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Sprite = _cc.Sprite;
      resources = _cc.resources;
      SpriteFrame = _cc.SpriteFrame;
    }, function (_unresolved_2) {
      beltMoveSpeedGlobal = _unresolved_2.beltMoveSpeedGlobal;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "31357qPB/pCvIS7sRTOKthl", "WasteMove", undefined);

      // import wasteItemsMap from './WasteList';
      ({
        ccclass,
        property
      } = _decorator);

      _export("WasteMove", WasteMove = (_dec = ccclass('WasteMove'), _dec2 = property(Prefab), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class WasteMove extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "wastePrefab", _descriptor, this);

          _initializerDefineProperty(this, "wasteItemsRoot", _descriptor2, this);

          _defineProperty(this, "_theSpriteFrame", null);

          _defineProperty(this, "_theSpriteFrameSet", null);

          _defineProperty(this, "_wasteMoveSpeed", 10);

          _defineProperty(this, "_wastePositionY", 0);

          _defineProperty(this, "_wasteMovingRange", -580);
        }

        // private newWasteItem: Node = null
        onLoad() {
          // single resource load:
          // let path = "textures/wastes/generalWaste/1_plastic_straws/spriteFrame"
          // let path = "textures/wastes/recycling/1_cardboard/spriteFrame"
          // resources.load(path, SpriteFrame, (err, theSpriteFrame) =>{
          //     // Log print if resource loading failed
          //     // console.log('Log the spriteFrame loaded...')
          //     // console.log(theSpriteFrame)
          //     // console.log(err)
          //     // console.log(err.name)
          //     // console.log(err.message)            
          //     this._theSpriteFrame = theSpriteFrame
          // })
          // load all SpriteFrame resources in a folder
          // resources.loadDir("textures/wastes", SpriteFrame, function (err, theAssets) {
          //     console.log("load folder...")
          //     console.log(theAssets)
          //     // _theSpriteFrameSet = theAssets
          // });
          resources.loadDir("textures/wastes", SpriteFrame, null, (err, assets) => this.loadSpriteFrames(err, assets));
        }

        loadSpriteFrames(err, theAssets) {
          console.log("load all SpriteFrames from folder...");
          this._theSpriteFrameSet = theAssets;
          console.log(this._theSpriteFrameSet);
        }

        start() {
          this._wasteMoveSpeed = _crd && beltMoveSpeedGlobal === void 0 ? (_reportPossibleCrUseOfbeltMoveSpeedGlobal({
            error: Error()
          }), beltMoveSpeedGlobal) : beltMoveSpeedGlobal;
          this.schedule(() => {
            var newWasteItem = null;
            newWasteItem = instantiate(this.wastePrefab);
            newWasteItem.parent = this.wasteItemsRoot; // director.getScene().getChildByName('Canvas').addChild(newWasteItem)
            // resources.load("wastes/recycling/1_cardboard", SpriteFrame, (err, SpriteFrame) =>{
            // resources.load("textures/wastes/generalWaste/1_plastic_straws/spriteFrame", SpriteFrame, (err, theSpriteFrame) =>{      
            //     newWasteItem.getComponent(Sprite).spriteFrame = theSpriteFrame
            // })
            // get a SpriteFrame randomly

            var _spriteIndex = Math.floor(Math.random() * this._theSpriteFrameSet.length);

            this._theSpriteFrame = this._theSpriteFrameSet[_spriteIndex]; // assign the SpriteFrame to the waste item

            newWasteItem.getComponent(Sprite).spriteFrame = this._theSpriteFrame;
            newWasteItem.active = true;
            newWasteItem.setPosition(0, this._wastePositionY, 0); // the position is the relative position to the parent object
          }, 3);
        }

        update(deltaTime) {
          for (var wasteItem of this.wasteItemsRoot.children) {
            wasteItem.setPosition(wasteItem.position.x - this._wasteMoveSpeed * deltaTime, wasteItem.position.y, 0); // if (wasteItem.position.x < this._wasteMovingRange){
            //     wasteItem.destroy()
            // }
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "wastePrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "wasteItemsRoot", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=WasteMove.js.map