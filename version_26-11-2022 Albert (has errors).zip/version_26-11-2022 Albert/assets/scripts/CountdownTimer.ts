
import { _decorator, Component, Node, find, Label, director, AudioSource} from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = CountdownTimer
 * DateTime = Sat Oct 22 2022 23:08:00 GMT+1300 (New Zealand Daylight Time)
 * Author = Albert4107
 * FileBasename = CountdownTimer.ts
 * FileBasenameNoExtension = CountdownTimer
 * URL = db://assets/scripts/CountdownTimer.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('CountdownTimer')
export class CountdownTimer extends Component {
	private TimeElapsed = 0

	@property(Node)
	TimerText: Node = null

	@property(Number)
	InitialSecs: Number = 120

	public secs = 0
	private intervalID = null

	private mins = 0
	private remainder = 0

	start () {
		this.TimerText = find("Canvas/TimerGUI/TimerLabel")
		this.secs = this.InitialSecs.valueOf()
		this.updateText()
		//this.intervalID = setInterval(this.incrementSecs, 1000)
		this.schedule(function() {
			this.incrementSecs();
		}, 1);
		find("Canvas/Audio").getComponent(AudioSource).play()
	}

	incrementSecs(){
		if (this.secs > 0){
			this.secs --
			this.updateText()
		}else{
			director.loadScene("scene-end")
		}
		
	}

	updateText(){
		this.mins = Math.floor(this.secs/60)
		this.remainder = this.secs % 60

		let out1 = this.mins.toString() + " : "
		if(this.remainder < 10){
			out1 = out1 + "0"
		}
		out1 = out1 + this.remainder.toString()
		this.TimerText.getComponent(Label).string = out1
	}
}