System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, resources, SpriteFrame, ResourceManager, _crd;

  _export("default", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      resources = _cc.resources;
      SpriteFrame = _cc.SpriteFrame;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "de70bBElOVGDbeDjxYVrAoB", "ResourceManager", undefined);

      _export("default", ResourceManager = class ResourceManager {
        loadDir(path, type) {
          if (type === void 0) {
            type = SpriteFrame;
          }

          return new Promise((resolve, reject) => {
            resources.loadDir(path, type, function (err, assets) {
              if (err) {
                reject(err);
                return;
              }

              resolve(assets);
            });
          });
        }

      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ResourceManager.js.map