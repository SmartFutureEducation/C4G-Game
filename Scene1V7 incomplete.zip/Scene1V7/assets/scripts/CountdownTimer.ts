
import { _decorator, Component, Node, find, Label} from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = CountdownTimer
 * DateTime = Sat Oct 22 2022 23:08:00 GMT+1300 (New Zealand Daylight Time)
 * Author = Albert4107
 * FileBasename = CountdownTimer.ts
 * FileBasenameNoExtension = CountdownTimer
 * URL = db://assets/scripts/CountdownTimer.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('CountdownTimer')
export class CountdownTimer extends Component {
	private TimeElapsed = 0

	@property(Node)
	TimerText: Node = null

	@property(Number)
	InitialSecs: Number = 120

	public secs = 0
	private intervalID = null

	start () {
		this.TimerText = find("Canvas/TimerGUI/TimerLabel")
		this.secs = this.InitialSecs.valueOf()
		this.updateText()
		this.intervalID = setInterval(this.incrementSecs, 1000)
	}

	incrementSecs(){
		if (this.secs > 0){
			this.secs --
			this.updateText()
		}else{
			clearInterval(this.intervalID)
			// something
		}
		
	}

	updateText(){
		let mins = 0
		let secsleft = 0

		mins = Math.floor(this.secs/60)
		secsleft = this.secs % 60

		let out1 = mins.toString()
		out1 = out1 + " : "
		if(secsleft >= 10){
			out1 = out1 + secsleft.toString()
		}else{
			out1 = out1 + "0"
			out1 = out1 + secsleft.toString()
		}
		this.TimerText.getComponent(Label).string = out1
	}
}