
import { _decorator, Component, Node } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = CountdownTimer
 * DateTime = Sat Oct 22 2022 23:08:00 GMT+1300 (New Zealand Daylight Time)
 * Author = Albert4107
 * FileBasename = CountdownTimer.ts
 * FileBasenameNoExtension = CountdownTimer
 * URL = db://assets/scripts/CountdownTimer.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('CountdownTimer')
export class CountdownTimer extends Component {
	
	

}

