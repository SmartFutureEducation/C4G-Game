System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: async function () {
      // Auto generated represents the prerequisite imports of project modules.
      await (async () => {
        const requests = [() => _context.import("__unresolved_0"), () => _context.import("__unresolved_1"), () => _context.import("__unresolved_2"), () => _context.import("__unresolved_3"), () => _context.import("__unresolved_4"), () => _context.import("__unresolved_5"), () => _context.import("__unresolved_6"), () => _context.import("__unresolved_7"), () => _context.import("__unresolved_8"), () => _context.import("__unresolved_9"), () => _context.import("__unresolved_10"), () => _context.import("__unresolved_11"), () => _context.import("__unresolved_12"), () => _context.import("__unresolved_13"), () => _context.import("__unresolved_14")];

        for (const request of requests) {
          try {
            await request();
          } catch (_err) {// The error should have been caught by executor.
          }
        }
      })();
    }
  };
});
//# sourceMappingURL=prerequisite-imports.js.map