System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _crd, Waste_Type_Enum, wasteItemsMap;

  _export("Waste_Type_Enum", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "40e8eUoqKlEIqsX9R0QK1fA", "WasteList", undefined);

      (function (Waste_Type_Enum) {
        Waste_Type_Enum["General_Waste"] = "General_Waste";
        Waste_Type_Enum["Recycling"] = "Recycling";
      })(Waste_Type_Enum || _export("Waste_Type_Enum", Waste_Type_Enum = {}));

      wasteItemsMap = new Map([// Ref: https://howtodoinjava.com/typescript/maps/
      ["plastic_straws", Waste_Type_Enum.General_Waste], ["toy", Waste_Type_Enum.General_Waste], ["cardboard", Waste_Type_Enum.Recycling], ["plastic_bottles", Waste_Type_Enum.Recycling], ["plastic_wrap", Waste_Type_Enum.General_Waste], ["pizza_box", Waste_Type_Enum.Recycling], ["egg_carton", Waste_Type_Enum.Recycling], ["disposable_cup", Waste_Type_Enum.General_Waste], ["cardboard", Waste_Type_Enum.Recycling], ["broken_glass", Waste_Type_Enum.General_Waste], ["aluminium_cans", Waste_Type_Enum.Recycling]]);

      _export("default", wasteItemsMap); // const wastes = [
      //   {
      //     name: "gwaste_plastic_straws",
      //     type: Waste_Type_Enum.General_Waste,
      //   },
      //   {
      //     name: "gwaste_toy",
      //     type: Waste_Type_Enum.General_Waste,
      //   },
      //   {
      //     name: "recycle_cardboard",
      //     type: Waste_Type_Enum.Recycling,
      //   },
      //   {
      //     name: "recycle_plastic_bottles",
      //     type: Waste_Type_Enum.Recycling,
      //   },
      // ];
      //  //If more complext waste definition: 
      // type Waste = {
      //     name: string
      //     type: Waste_Type_Enum
      // }
      // const wastesList: {[name: string]: Waste} = {}
      // const wastesList: {[name: string]: Waste_Type_Enum} = {}
      // wastesList.gwaste_plastic_straws = Waste_Type_Enum.General_Waste
      // wastesList.gwaste_toy = Waste_Type_Enum.General_Waste


      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=WasteList.js.map