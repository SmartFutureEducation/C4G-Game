
import { _decorator, Component, Node, find, Label } from 'cc';
import { GameManager } from './GameManager';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = GameOverSummary
 * DateTime = Sun Nov 27 2022 23:36:00 GMT+1300 (New Zealand Daylight Time)
 * Author = jackhasaboat
 * FileBasename = GameOverSummary.ts
 * FileBasenameNoExtension = GameOverSummary
 * URL = db://assets/scripts/GameOverSummary.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('GameOverSummary')
export class GameOverSummary extends Component {
    // emissions in Rugby size
    emission_number_label: Node = null
    emission_rugby_label: Node = null

    onLoad(){
        // show the final emisssion number
        this.emission_number_label = find("Canvas/finalEmission")
        this.emission_number_label.getComponent(Label).string = "Total Emissions: " + GameManager.Instance.emissionTotal.toString() + "  kgCO₂e"
 
        // show the final calculated Rugby number
        this.emission_rugby_label = find("Canvas/finalRugbyNumber")
        // this.emission_rugby_label.getComponent(Label).string = "In Rugby size: " + GameManager.Instance.rugbyTotal.toString()
        this.emission_rugby_label.getComponent(Label).string = GameManager.Instance.rugbyTotal.toString()
    }


    start () {
        // [3]
    }
    

    // update (deltaTime: number) {
    //     // [4]
    // }
}
