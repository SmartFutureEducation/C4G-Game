System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, Collider2D, Contact2DType, Sprite, Color, _dec, _dec2, _class, _class2, _descriptor, _temp, _crd, ccclass, property, WasteCollect;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Collider2D = _cc.Collider2D;
      Contact2DType = _cc.Contact2DType;
      Sprite = _cc.Sprite;
      Color = _cc.Color;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "906fdghJe5KfYXtzaaDo4U3", "WasteCollect", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("WasteCollect", WasteCollect = (_dec = ccclass('WasteCollect'), _dec2 = property(Node), _dec(_class = (_class2 = (_temp = class WasteCollect extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "scoreBoard", _descriptor, this);

          _defineProperty(this, "isWasteCollected", false);
        }

        // reference full scripts from help doc https://docs.cocos.com/creator/manual/en/physics-2d/physics-2d-contact-callback.html
        start() {
          // Registering callback functions for a single collider
          var collider = this.getComponent(Collider2D);

          if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            collider.on(Contact2DType.END_CONTACT, this.onEndContact, this);
            collider.on(Contact2DType.PRE_SOLVE, this.onPreSolve, this);
            collider.on(Contact2DType.POST_SOLVE, this.onPostSolve, this);
          }
        }

        onBeginContact(selfCollider, otherCollider, contact) {
          // will be called once when two colliders begin to contact
          console.log('onBeginContact');
          this.isWasteCollected = true; // score
          // this.scoreBoard.getComponent(Label).string = (Number(this.scoreBoard.getComponent(Label).string) + 10).toString()

          if (otherCollider.tag == 11) {
            this.node.getComponent(Sprite).color = new Color(255, 255, 0);
          } else if (otherCollider.tag == 12) {
            this.node.getComponent(Sprite).color = new Color(255, 0, 0);
          }

          this.node.setScale(0.75, 0.75, 0.75); // const animationComponent = this.node.getComponent(Animation);
          // animationComponent.play()

          setTimeout(() => {
            this.node.destroy();
          }, 500); // seems the timeout is required, else errors will be reported while running
        }

        onEndContact(selfCollider, otherCollider, contact) {
          // will be called once when the contact between two colliders just about to end.
          console.log('onEndContact');
        }

        onPreSolve(selfCollider, otherCollider, contact) {
          // will be called every time collider contact should be resolved
          console.log('onPreSolve');
        }

        onPostSolve(selfCollider, otherCollider, contact) {
          // will be called every time collider contact should be resolved
          console.log('onPostSolve');
        }

        update(deltaTime) {// if (this.isWasteCollected == false){
          //     this.node.setPosition(this.node.position.x, this.node.position.y - 50 * deltaTime) 
          // }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "scoreBoard", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=WasteCollect.js.map