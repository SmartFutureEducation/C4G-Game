export enum Waste_Type_Enum {
  General_Waste = "General_Waste",
  Recycling = "Recycling",
}

// let wasteItemsMap = new Map<string, Waste_Type_Enum>([  // Ref: https://howtodoinjava.com/typescript/maps/
//     ["gwaste_plastic_straws", Waste_Type_Enum.General_Waste],
//     ["gwaste_toy", Waste_Type_Enum.General_Waste],
//     ["gwaste_banana", Waste_Type_Enum.General_Waste],
//     ["recycle_cardboard", Waste_Type_Enum.Recycling],
//     ["recycle_plastic_bottles", Waste_Type_Enum.Recycling]
// ]);
// export default wasteItemsMap;

class Waste{
  name: string = ''
  wasteType: string = 'Unknown'
  weightInGram: number = 0
  material: string = ''
  description: string = ''

  constructor(name:string, type:Waste_Type_Enum, weight: number, material='Unknown', description='No description') {
      this.name = name;
      this.wasteType = type;
      this.weightInGram = weight;
      this.material = material;
      this.description = description
  }
}

let wasteItems = new Map<string, Waste>([ 
  ["gwaste_plastic_straws", new Waste('gwaste_plastic_straws', Waste_Type_Enum.General_Waste,42, 'Plastic(unspecified type)', '100 plastic straws')],
  ["gwaste_toy", new Waste('gwaste_toy', Waste_Type_Enum.General_Waste,500, 'material_placeholder', 'description_placeholder')],
  ["gwaste_banana", new Waste('gwaste_banana', Waste_Type_Enum.General_Waste,100, 'material_placeholder', 'description_placeholder')],
  ["recycle_cardboard", new Waste('recycle_cardboard', Waste_Type_Enum.Recycling,200, 'material_placeholder', 'description_placeholder')],
  ["recycle_plastic_bottles", new Waste('recycle_plastic_bottles', Waste_Type_Enum.Recycling,144, 'Plastic(unspecified type)', '6 plastic bottles')],
  // unfinished:
  ["gwaste_plastic_wrap", new Waste('gwaste_plastic_wrap', Waste_Type_Enum.General_Waste,1, 'material_placeholder', 'description_placeholder')],
  ["recycle_pizza_box", new Waste('recycle_pizza_box', Waste_Type_Enum.General_Waste,1, 'material_placeholder', 'description_placeholder')],
  ["recycle_egg_carton", new Waste('recycle_egg_carton', Waste_Type_Enum.General_Waste,1, 'material_placeholder', 'description_placeholder')],
  ["gwaste_disposable_cup", new Waste('gwaste_disposable_cup', Waste_Type_Enum.General_Waste,1, 'material_placeholder', 'description_placeholder')],
  ["recycle_broken_glass", new Waste('recycle_broken_glass', Waste_Type_Enum.General_Waste,1, 'material_placeholder', 'description_placeholder')],
  ["recycle_aluminium_cans", new Waste('recycle_aluminium_cans', Waste_Type_Enum.General_Waste,1, 'material_placeholder', 'description_placeholder')]
]);
export default wasteItems;

// const wastes = [
//   {
//     name: "gwaste_plastic_straws",
//     type: Waste_Type_Enum.General_Waste,
//   },
//   {
//     name: "gwaste_toy",
//     type: Waste_Type_Enum.General_Waste,
//   },
//   {
//     name: "recycle_cardboard",
//     type: Waste_Type_Enum.Recycling,
//   },
//   {
//     name: "recycle_plastic_bottles",
//     type: Waste_Type_Enum.Recycling,
//   },
// ];

//  //If more complext waste definition: 
// type Waste = {
//     name: string
//     type: Waste_Type_Enum
// }
// const wastesList: {[name: string]: Waste} = {}

// const wastesList: {[name: string]: Waste_Type_Enum} = {}
// wastesList.gwaste_plastic_straws = Waste_Type_Enum.General_Waste
// wastesList.gwaste_toy = Waste_Type_Enum.General_Waste
