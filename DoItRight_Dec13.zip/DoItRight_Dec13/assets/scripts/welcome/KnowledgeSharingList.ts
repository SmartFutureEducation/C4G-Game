
// import { _decorator, Component, Node } from 'cc';
// const { ccclass, property } = _decorator;

const listInfo = [
      {
        src: "https://environment.govt.nz/facts-and-science/waste/estimates-of-waste-generated/#amount-of-waste-generated",
        src_short: "environment.govt.nz",
        content: "It is estimated that in Aotearoa New Zealand we generate 17.49 million tonnes of waste per year, of which an estimated 12.59 million tonnes are sent to landfill.",
      },
      {
        src: "https://www.recycle.co.nz/problemsize.php",
        src_short: "recycle.co.nz",
        content: "When we buy a product we also buy any waste associated with the product. We are all responsible for waste. It starts with us. It ends with us.",
      },
      {
        src: "https://www.rnz.co.nz/programmes/the-detail/story/2018802777/waste-minimisation-efforts-slow-to-take-hold#:~:text=In%202018%20the%20World%20Bank,kg%20of%20rubbish%20a%20day.",
        src_short: "rnz.co.nz",
        content: "In 2018 the World Bank ranked New Zealand as the 10th most wasteful country in the world per capita with Kiwis producing 3.6kg of rubbish a day.",
      },
      {
        src: "google.com",
        src_short: "google.com",
        content: "Everybody can do a better job to reduce the waste.",
      },
      {
        src: "Auckland Waste Management and Minimisation Plan",
        src_short: "Auckland Waste Management and Minimisation Plan",
        content: "Re-cycle is the catch-cry. Zero waste is the bold goal.",
      },
      {
        src: "Auckland Waste Management and Minimisation Plan",
        src_short: "Auckland Waste Management and Minimisation Plan",
        content: "Every tonne of waste that is landfilled comes at a cost. We currently spend around $113 million per year on domestic waste services.",
      },
      {
        src: "Auckland Waste Management and Minimisation Plan",
        src_short: "Auckland Waste Management and Minimisation Plan",
        content: "Auckland aspires to be Zero Waste by 2040.",
      },
      {
        src: "Auckland Waste Management and Minimisation Plan",
        src_short: "Auckland Waste Management and Minimisation Plan",
        content: "This was a world of zero waste in the beginning. We must make her waste-free once more.",
      },
      {
        src: "Auckland Waste Management and Minimisation Plan",
        src_short: "Auckland Waste Management and Minimisation Plan",
        content: "Waste is possible to be turned into commodities and resources.",
      },
      {
        src: "by Nigel",
        src_short: "by Nigel",
        content: "There is no waste but the resources that we put them into a wrong place.",
      }
  ];

export default listInfo
