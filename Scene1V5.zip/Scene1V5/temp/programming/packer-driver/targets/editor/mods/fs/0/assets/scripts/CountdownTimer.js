System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, _dec, _class, _crd, ccclass, property, CountdownTimer;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "52dbdY6NnpNT70CskQQSJ+T", "CountdownTimer", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * Predefined variables
       * Name = CountdownTimer
       * DateTime = Sat Oct 22 2022 23:08:00 GMT+1300 (New Zealand Daylight Time)
       * Author = Albert4107
       * FileBasename = CountdownTimer.ts
       * FileBasenameNoExtension = CountdownTimer
       * URL = db://assets/scripts/CountdownTimer.ts
       * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
       *
       */

      _export("CountdownTimer", CountdownTimer = (_dec = ccclass('CountdownTimer'), _dec(_class = class CountdownTimer extends Component {}) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=CountdownTimer.js.map