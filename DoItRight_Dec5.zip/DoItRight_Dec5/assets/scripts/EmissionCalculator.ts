
import { _decorator, Component, Node, CCInteger } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = EmisssionCalculator
 * DateTime = Sun Nov 20 2022 13:13:55 GMT+1300 (New Zealand Daylight Time)
 * Author = jackhasaboat
 * FileBasename = EmisssionCalculator.ts
 * FileBasenameNoExtension = EmisssionCalculator
 * URL = db://assets/scripts/EmisssionCalculator.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('EmisssionCalculator')
export class EmisssionCalculator extends Component {

    emission_factor = 0.207     //1kg= 0.207kgCO2e
    rugby_factor = 124          //1kgCO2e = 124 rugby balls

    start () {
        // [3]
    }

    calculateEmissionkgCo2(weightInGram: number){
        // return (weightInGram/1000 * this.emission_factor).toFixed(3)
        return Math.round(weightInGram * this.emission_factor)/1000
    }

    calculateEmissionInRugbySize(weightInGram: number){
        return Math.round(this.calculateEmissionkgCo2(weightInGram) * this.rugby_factor * 1000) / 1000
    }

    // update (deltaTime: number) {
    //     // [4]
    // }
}

