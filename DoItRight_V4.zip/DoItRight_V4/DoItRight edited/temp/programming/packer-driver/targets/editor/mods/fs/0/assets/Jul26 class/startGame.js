System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, director, _dec, _class, _crd, ccclass, property, startGame;

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      director = _cc.director;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "e945fQrrN1L54SOpk46kmWW", "startGame", undefined);

      ({
        ccclass,
        property
      } = _decorator);
      /**
       * Predefined variables
       * Name = startGame
       * DateTime = Tue Jul 26 2022 19:17:10 GMT+1200 (New Zealand Standard Time)
       * Author = jackhasaboat
       * FileBasename = startGame.ts
       * FileBasenameNoExtension = startGame
       * URL = db://assets/startGame.ts
       * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
       *
       */

      _export("startGame", startGame = (_dec = ccclass('startGame'), _dec(_class = class startGame extends Component {
        start() {// [3]
        }

        onLoad() {
          this.node.on('click', this.callback, this);
        }

        callback(event) {
          director.loadScene("scene-game-main");
        } // update (deltaTime: number) {
        //     // [4]
        // }


      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=startGame.js.map