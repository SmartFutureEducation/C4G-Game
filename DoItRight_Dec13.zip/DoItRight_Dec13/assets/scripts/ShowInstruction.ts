
import { _decorator, Component, Node, find } from 'cc';
const { ccclass, property } = _decorator;

/**
 * Predefined variables
 * Name = ShowInstruction
 * DateTime = Wed Dec 07 2022 21:56:54 GMT+1300 (New Zealand Daylight Time)
 * Author = jackhasaboat
 * FileBasename = ShowInstruction.ts
 * FileBasenameNoExtension = ShowInstruction
 * URL = db://assets/scripts/ShowInstruction.ts
 * ManualUrl = https://docs.cocos.com/creator/3.4/manual/en/
 *
 */
 
@ccclass('ShowInstruction')
export class ShowInstruction extends Component {
    
    instructionPage: Node = null

    start () {
        this.instructionPage = find("Canvas/instruction_page")
    }
    
    onLoad () {
        this.node.on('click', this.callback, this);
    }
     
    callback(event) {
        this.instructionPage.active = true
        
    }

}
