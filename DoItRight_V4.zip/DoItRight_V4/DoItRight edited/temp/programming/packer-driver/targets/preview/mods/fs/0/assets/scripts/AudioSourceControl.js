System.register(["__unresolved_0"], function (_export, _context) {
  "use strict";

  var _loader, _cjsExports, __cjsMetaURL;

  _export("default", void 0);

  return {
    setters: [function (_unresolved_) {
      _loader = _unresolved_.default;
    }],
    execute: function () {
      _loader.define(_context.meta.url, function (exports, _require, module, __filename, __dirname) {
        var require = _loader.createRequireWithReqMap({}, _require);

        (function () {
          cc.Class({
            extends: cc.Component,
            properties: {
              audioSource: {
                type: cc.AudioSource,
                default: null
              }
            },
            play: function play() {
              this.audioSource.play();
            },
            pause: function pause() {
              this.audioSource.pause();
            }
          });
        })();

        _export("default", _cjsExports = module.exports);
      });

      _export("__cjsMetaURL", __cjsMetaURL = _context.meta.url);
    }
  };
});
//# sourceMappingURL=AudioSourceControl.js.map