
import { _decorator, Component, Node, Collider2D, Contact2DType, IPhysics2DContact, Sprite, Color } from 'cc';
const { ccclass, property } = _decorator;

 
@ccclass('WasteCollect')
export class WasteCollect extends Component {

    @property(Node)
    scoreBoard: Node = null

    isWasteCollected: boolean = false

    // reference full scripts from help doc https://docs.cocos.com/creator/manual/en/physics-2d/physics-2d-contact-callback.html
    start () {
        // Registering callback functions for a single collider
        let collider = this.getComponent(Collider2D);
        if (collider) {
            collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
            collider.on(Contact2DType.END_CONTACT, this.onEndContact, this);
            collider.on(Contact2DType.PRE_SOLVE, this.onPreSolve, this);
            collider.on(Contact2DType.POST_SOLVE, this.onPostSolve, this);
        }

    }

    onBeginContact (selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        // will be called once when two colliders begin to contact
        console.log('onBeginContact');

        this.isWasteCollected = true

        // score
        // this.scoreBoard.getComponent(Label).string = (Number(this.scoreBoard.getComponent(Label).string) + 10).toString()

        if (otherCollider.tag == 11){
            this.node.getComponent(Sprite).color = new Color(255,255,0)
        }else if (otherCollider.tag == 12){
            this.node.getComponent(Sprite).color = new Color(255,0,0)
        }
        this.node.setScale(0.75, 0.75, 0.75)


        // const animationComponent = this.node.getComponent(Animation);
        // animationComponent.play()
        
        setTimeout(() => {
            this.node.destroy();
        }, 500);  // seems the timeout is required, else errors will be reported while running
        
    }
    onEndContact (selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        // will be called once when the contact between two colliders just about to end.
        console.log('onEndContact');
    }
    onPreSolve (selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        // will be called every time collider contact should be resolved
        console.log('onPreSolve');
    }
    onPostSolve (selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
        // will be called every time collider contact should be resolved
        console.log('onPostSolve');
    }


    update (deltaTime: number) {
        // if (this.isWasteCollected == false){
        //     this.node.setPosition(this.node.position.x, this.node.position.y - 50 * deltaTime) 
        // }
    }
}