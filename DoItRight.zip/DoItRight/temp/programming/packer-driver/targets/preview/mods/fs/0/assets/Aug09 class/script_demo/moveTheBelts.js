System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, _decorator, Component, Node, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _temp, _crd, ccclass, property, BeltMoveDemo;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "814401irBxLQqxXNvXECua3", "moveTheBelts", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("BeltMoveDemo", BeltMoveDemo = (_dec = ccclass('BeltMoveDemo'), _dec2 = property(Node), _dec3 = property(Node), _dec4 = property(Number), _dec(_class = (_class2 = (_temp = class BeltMoveDemo extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "belt_1", _descriptor, this);

          _initializerDefineProperty(this, "belt_2", _descriptor2, this);

          _initializerDefineProperty(this, "speed", _descriptor3, this);

          _defineProperty(this, "_beltY", 0);

          _defineProperty(this, "_beltMovingRange", 960);
        }

        start() {
          this._init();
        }

        _init() {
          console.log('Conveyor Belt Initing..');
          console.log(this);
          console.log('Belt_1...');
          console.log(this.belt_1);
          this.belt_1.setPosition(0, this._beltY, 0);
          console.log('Belt_2...');
          console.log(this.belt_2);
          this.belt_2.setPosition(960, this._beltY, 0);
        }

        update(deltaTime) {
          this._beltMove(deltaTime);
        }

        _beltMove(deltaTime) {
          this.belt_1.setPosition(this.belt_1.position.x - this.speed * deltaTime, this._beltY, 0);

          if (this.belt_1.position.x < -this._beltMovingRange) {
            this.belt_1.setPosition(this._beltMovingRange, this._beltY, 0);
          }

          this.belt_2.setPosition(this.belt_2.position.x - this.speed * deltaTime, this._beltY, 0);

          if (this.belt_2.position.x < -this._beltMovingRange) {
            this.belt_2.setPosition(this._beltMovingRange, this._beltY, 0);
          }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "belt_1", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "belt_2", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "speed", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return 10;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=moveTheBelts.js.map