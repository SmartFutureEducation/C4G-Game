export enum Waste_Type_Enum {
  General_Waste = "General_Waste",
  Recycling = "Recycling",
}

// let wasteItemsMap = new Map<string, Waste_Type_Enum>([  // Ref: https://howtodoinjava.com/typescript/maps/
//     ["gwaste_plastic_straws", Waste_Type_Enum.General_Waste],
//     ["gwaste_toy", Waste_Type_Enum.General_Waste],
//     ["gwaste_banana", Waste_Type_Enum.General_Waste],
//     ["recycle_cardboard", Waste_Type_Enum.Recycling],
//     ["recycle_plastic_bottles", Waste_Type_Enum.Recycling]
// ]);
// export default wasteItemsMap;

class Waste{
  name: string = ''
  wasteType: string = 'Unknown'
  weightInGram: number = 0
  material: string = ''
  description: string = ''

  constructor(name:string, type:Waste_Type_Enum, weight: number, material='Unknown', description='No description') {
      this.name = name;
      this.wasteType = type;
      this.weightInGram = weight;
      this.material = material;
      this.description = description
  }
}

let wasteItems = new Map<string, Waste>([ 
  ["gwaste_plastic_straws", new Waste('gwaste_plastic_straws', Waste_Type_Enum.General_Waste,42, 'Plastic', '100 plastic straws')],
  ["gwaste_toy", new Waste('gwaste_toy', Waste_Type_Enum.General_Waste,500)],
  ["gwaste_banana", new Waste('gwaste_banana', Waste_Type_Enum.General_Waste,100)],
  ["recycle_cardboard", new Waste('recycle_cardboard', Waste_Type_Enum.Recycling,200)],
  ["recycle_plastic_bottles", new Waste('recycle_plastic_bottles', Waste_Type_Enum.Recycling,144, 'Plastic', '6 plastic bottles')]

]);
export default wasteItems;

// const wastes = [
//   {
//     name: "gwaste_plastic_straws",
//     type: Waste_Type_Enum.General_Waste,
//   },
//   {
//     name: "gwaste_toy",
//     type: Waste_Type_Enum.General_Waste,
//   },
//   {
//     name: "recycle_cardboard",
//     type: Waste_Type_Enum.Recycling,
//   },
//   {
//     name: "recycle_plastic_bottles",
//     type: Waste_Type_Enum.Recycling,
//   },
// ];

//  //If more complext waste definition: 
// type Waste = {
//     name: string
//     type: Waste_Type_Enum
// }
// const wastesList: {[name: string]: Waste} = {}

// const wastesList: {[name: string]: Waste_Type_Enum} = {}
// wastesList.gwaste_plastic_straws = Waste_Type_Enum.General_Waste
// wastesList.gwaste_toy = Waste_Type_Enum.General_Waste
