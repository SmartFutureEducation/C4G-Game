System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, Waste, _crd, Waste_Type_Enum, wasteItems;

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  _export("Waste_Type_Enum", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "40e8eUoqKlEIqsX9R0QK1fA", "WasteList", undefined);

      (function (Waste_Type_Enum) {
        Waste_Type_Enum["General_Waste"] = "General_Waste";
        Waste_Type_Enum["Recycling"] = "Recycling";
      })(Waste_Type_Enum || _export("Waste_Type_Enum", Waste_Type_Enum = {}));

      // let wasteItemsMap = new Map<string, Waste_Type_Enum>([  // Ref: https://howtodoinjava.com/typescript/maps/
      //     ["gwaste_plastic_straws", Waste_Type_Enum.General_Waste],
      //     ["gwaste_toy", Waste_Type_Enum.General_Waste],
      //     ["gwaste_banana", Waste_Type_Enum.General_Waste],
      //     ["recycle_cardboard", Waste_Type_Enum.Recycling],
      //     ["recycle_plastic_bottles", Waste_Type_Enum.Recycling]
      // ]);
      // export default wasteItemsMap;
      Waste = class Waste {
        constructor(name, type, weight, material, description) {
          if (material === void 0) {
            material = 'Unknown';
          }

          if (description === void 0) {
            description = 'No description';
          }

          _defineProperty(this, "name", '');

          _defineProperty(this, "wasteType", 'Unknown');

          _defineProperty(this, "weightInGram", 0);

          _defineProperty(this, "material", '');

          _defineProperty(this, "description", '');

          this.name = name;
          this.wasteType = type;
          this.weightInGram = weight;
          this.material = material;
          this.description = description;
        }

      };
      wasteItems = new Map([["gwaste_plastic_straws", new Waste('gwaste_plastic_straws', Waste_Type_Enum.General_Waste, 42, 'Plastic(unspecified type)', '100 plastic straws')], ["gwaste_toy", new Waste('gwaste_toy', Waste_Type_Enum.General_Waste, 500, 'material_placeholder', 'description_placeholder')], ["gwaste_banana", new Waste('gwaste_banana', Waste_Type_Enum.General_Waste, 100, 'material_placeholder', 'description_placeholder')], ["recycle_cardboard", new Waste('recycle_cardboard', Waste_Type_Enum.Recycling, 200, 'material_placeholder', 'description_placeholder')], ["recycle_plastic_bottles", new Waste('recycle_plastic_bottles', Waste_Type_Enum.Recycling, 144, 'Plastic(unspecified type)', '6 plastic bottles')], // unfinished:
      ["gwaste_plastic_wrap", new Waste('gwaste_plastic_wrap', Waste_Type_Enum.General_Waste, 1, 'material_placeholder', 'description_placeholder')], ["recycle_pizza_box", new Waste('recycle_pizza_box', Waste_Type_Enum.General_Waste, 1, 'material_placeholder', 'description_placeholder')], ["recycle_egg_carton", new Waste('recycle_egg_carton', Waste_Type_Enum.General_Waste, 1, 'material_placeholder', 'description_placeholder')], ["gwaste_disposable_cup", new Waste('gwaste_disposable_cup', Waste_Type_Enum.General_Waste, 1, 'material_placeholder', 'description_placeholder')], ["recycle_broken_glass", new Waste('recycle_broken_glass', Waste_Type_Enum.General_Waste, 1, 'material_placeholder', 'description_placeholder')], ["recycle_aluminium_cans", new Waste('recycle_aluminium_cans', Waste_Type_Enum.General_Waste, 1, 'material_placeholder', 'description_placeholder')]]);

      _export("default", wasteItems); // const wastes = [
      //   {
      //     name: "gwaste_plastic_straws",
      //     type: Waste_Type_Enum.General_Waste,
      //   },
      //   {
      //     name: "gwaste_toy",
      //     type: Waste_Type_Enum.General_Waste,
      //   },
      //   {
      //     name: "recycle_cardboard",
      //     type: Waste_Type_Enum.Recycling,
      //   },
      //   {
      //     name: "recycle_plastic_bottles",
      //     type: Waste_Type_Enum.Recycling,
      //   },
      // ];
      //  //If more complext waste definition: 
      // type Waste = {
      //     name: string
      //     type: Waste_Type_Enum
      // }
      // const wastesList: {[name: string]: Waste} = {}
      // const wastesList: {[name: string]: Waste_Type_Enum} = {}
      // wastesList.gwaste_plastic_straws = Waste_Type_Enum.General_Waste
      // wastesList.gwaste_toy = Waste_Type_Enum.General_Waste


      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=WasteList.js.map