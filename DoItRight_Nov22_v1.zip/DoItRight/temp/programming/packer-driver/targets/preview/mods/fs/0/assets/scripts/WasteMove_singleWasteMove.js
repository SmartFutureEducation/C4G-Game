System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, _decorator, Component, Node, Prefab, instantiate, Sprite, resources, SpriteFrame, director, beltMoveSpeedGlobal, _dec, _dec2, _dec3, _class, _class2, _descriptor, _descriptor2, _temp, _crd, ccclass, property, WasteMove_bak;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'proposal-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfbeltMoveSpeedGlobal(extras) {
    _reporterNs.report("beltMoveSpeedGlobal", "./GameManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Node = _cc.Node;
      Prefab = _cc.Prefab;
      instantiate = _cc.instantiate;
      Sprite = _cc.Sprite;
      resources = _cc.resources;
      SpriteFrame = _cc.SpriteFrame;
      director = _cc.director;
    }, function (_unresolved_2) {
      beltMoveSpeedGlobal = _unresolved_2.beltMoveSpeedGlobal;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "2862787MG9HXYM9NApWRv6e", "WasteMove_singleWasteMove", undefined);

      ({
        ccclass,
        property
      } = _decorator);

      _export("WasteMove_bak", WasteMove_bak = (_dec = ccclass('WasteMove_bak'), _dec2 = property(Prefab), _dec3 = property(Node), _dec(_class = (_class2 = (_temp = class WasteMove_bak extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "wastePrefab", _descriptor, this);

          _initializerDefineProperty(this, "wasteItemsRoot", _descriptor2, this);

          _defineProperty(this, "_wasteMoveSpeed", 10);

          _defineProperty(this, "_wastePositionY", 0);

          _defineProperty(this, "_wasteMovingRange", -580);

          _defineProperty(this, "newWasteItem", null);
        }

        onLoad() {}

        start() {
          this._wasteMoveSpeed = _crd && beltMoveSpeedGlobal === void 0 ? (_reportPossibleCrUseOfbeltMoveSpeedGlobal({
            error: Error()
          }), beltMoveSpeedGlobal) : beltMoveSpeedGlobal; // randomly create new waste item
          // this.schedule(()=>{
          //     let newWasteItem: Node = null
          //     newWasteItem = instantiate(this.wastePrefab)
          //     newWasteItem.parent = this.wasteItemsRoot
          //     // newWasteItem.getComponent(wasteHandling).scoreBoard = this.node.parent.getChildByName('MyScoreBoard')
          //     const spriteFrames = new ResourceManager().loadDir("resources/wastes/recycling")
          //     newWasteItem.getComponent(Sprite).spriteFrame = spriteFrames[0]
          //     newWasteItem.active = true
          //     // let number1 = 10
          //     // let stringA = "this is my string test"
          // }, 4);
          // let newWasteItem: Node = null

          this.newWasteItem = instantiate(this.wastePrefab); // newWasteItem.parent = this.wasteItemsRoot

          director.getScene().getChildByName('Canvas').addChild(this.newWasteItem); // resources.load("wastes/recycling/1_cardboard", SpriteFrame, (err, SpriteFrame) =>{

          resources.load("textures/wastes/generalWaste/1_plastic_straws/spriteFrame", SpriteFrame, (err, theSpriteFrame) => {
            // Log print if resource loading failed
            // console.log('Log the spriteFrame loaded...')
            // console.log(theSpriteFrame)
            // console.log(err)
            // console.log(err.name)
            // console.log(err.message)            
            this.newWasteItem.getComponent(Sprite).spriteFrame = theSpriteFrame;
          });
          this.newWasteItem.active = true;
          this.newWasteItem.setPosition(580, this._wastePositionY, 0);
        }

        update(deltaTime) {
          this.newWasteItem.setPosition(this.newWasteItem.position.x - this._wasteMoveSpeed * deltaTime, this.newWasteItem.position.y, 0); //     if (this.newWasteItem.position.x < this._wasteMovingRange){
          //         this.newWasteItem.destroy()
          //     }
        }

      }, _temp), (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "wastePrefab", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: null
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "wasteItemsRoot", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=WasteMove_singleWasteMove.js.map